//
//  ContentView.swift
//  TestingUI
//
//  Created by John Rydberg on 4/17/24.
//

import SwiftUI

struct ContentView: View {
    @State private var name:String = ""
    @State private var password:String = ""
    @State private var hidepass:String = "********"
    @State private var forgotEmail:String = ""
    @State private var createname:String = ""
    @State private var createpassword:String = ""
    @State private var settingPassword:String = ""
    @State private var settingPassword2:String = ""
    @State private var dontMatch = false
    
    @State var screen = 2
    var body: some View {
        if screen == 0{
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:90 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 160, y: 90)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:45 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 245, y:0)
            
            
            Text("Sign in").font(.custom("Jomhuria-Regular", fixedSize:90 )).shadow(radius: 5, x:0, y :7).position(x:130,y:-50)
            
            
            VStack(alignment:.leading,spacing:30){
                TextField("Email or Username", text: $name).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().padding(0.0).foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
                
                TextField("Password", text: $password).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
            }.position(x:200,y:-40)
            
            
            Button(action:{
                //change to forgot password page
                screen = 1
            }){
                Text("Forgot Password ?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.black)
            }.position(x:260,y:-70)
            
            HStack{
                Button(action:{
                    
                    
                }){
                    Text("Sign in").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 115)
                        .foregroundColor(.white)
                        .background(Color(red: 0.5, green: 0.15, blue: 0.72, opacity: 1.0))
                    .cornerRadius(30)          }
            }.position(x:200,y:-60)
            
            HStack{
                Text("Don't Have an account?").font(.custom("Jomhuria-Regular", fixedSize:35 ))
                
                
                Button(action:{
                    //change to sign up page
                    screen = 3
                }){
                    Text("Sign Up").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.black)
                }
                
            }
            
        }
        if screen == 1 {
            
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:90 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 160, y: 90)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:45 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 245, y:0)
            
            
            Text("Forgot Password?").font(.custom("Jomhuria-Regular", fixedSize:60 )).shadow(radius: 2, x:0, y :3).position(x:170,y:-50)
            
            Text("Enter your email to receive a link to reset your password").font(.custom("Jomhuria-Regular", fixedSize:36 )).shadow(radius: 2, x:0, y :3).frame(width: 300).position(x:185,y:-110)
            
            TextField("Email", text: $forgotEmail).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray).position(x:200,y:-70)
            
            
            
            HStack{
                Button(action:{
                    //Button to send reset email, currently just changes to reset password screen
                    screen = 2
                }){
                    Text("Send").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 115)
                        .foregroundColor(.white)
                        .background(Color(red: 0.5, green: 0.15, blue: 0.72, opacity: 1.0))
                    .cornerRadius(30)          }
            }.position(x:200,y:-110)
            
            HStack{
                Text("Already have an account?").font(.custom("Jomhuria-Regular", fixedSize:35 ))
                
                
                Button(action:{
                    //change to login page
                    screen = 0
                }){
                    Text("Sign In").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.black)
                }
                
            }
        }
        //reset password screen
        if screen == 2{
            
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:90 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 160, y: 90)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:45 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 245, y:-20)
            
            Text("Reset your Password").font(.custom("Jomhuria-Regular", fixedSize:60 )).shadow(radius: 2, x:0, y :3).position(x:200,y:-50)
            
            VStack(alignment:.leading,spacing:30){
                TextField("Enter New Password", text: $settingPassword).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().padding(0.0).foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
                
                TextField("Confirm Password", text: $settingPassword2).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
            }.position(x:200,y:-55)
            
            
            HStack{
                Button(action:{
                    //Button to sign in, current just sends you back to the starting page
                    if settingPassword == settingPassword2{
                        screen = 0
                        
                    }else{
                        dontMatch = true
                    }
                    
                    
                }){
                    Text("Confirm").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 115)
                        .foregroundColor(.white)
                        .background(Color(red: 0.5, green: 0.15, blue: 0.72, opacity: 1.0))
                    .cornerRadius(30)          }
                
                
            }.position(x:200,y:-10)
            
            if dontMatch == true{
                Text("passwords do not match").font(.custom("Jomhuria-Regular", fixedSize:40 )).position(x:200, y:-60).foregroundColor(.red)
            }
            
            
            
        }
        //sign up page
        if screen == 3{
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:90 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 160, y: 90)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:45 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 245, y:0)
            
            
            Text("Want to sign up?").font(.custom("Jomhuria-Regular", fixedSize:60 )).shadow(radius: 2, x:0, y :3).position(x:170,y:-50)
            
            Text("Enter your email and desired password to create an account").font(.custom("Jomhuria-Regular", fixedSize:36 )).shadow(radius: 2, x:0, y :3).frame(width: 300).position(x:185,y:-110)
            
            VStack(alignment:.leading,spacing:30){
                TextField("Enter Email", text: $createname).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().padding(0.0).foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
                
                TextField("Enter Password", text: $createpassword).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
            }.position(x:200,y:-95)
            
            
            HStack{
                Button(action:{
                    //Button to sign in, current just sends you back to the starting page
                    screen = 0
                    
                }){
                    Text("Sign up").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 115)
                        .foregroundColor(.white)
                        .background(Color(red: 0.5, green: 0.15, blue: 0.72, opacity: 1.0))
                    .cornerRadius(30)          }
            }.position(x:200,y:-10)
            
            HStack{
                Text("Already have an account?").font(.custom("Jomhuria-Regular", fixedSize:35 ))
                
                
                Button(action:{
                    //change to login page
                    screen = 0
                }){
                    Text("Log In").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.black)
                }
                
            }
            
        }
        
         
          
        
        
    }
}



#Preview {
    ContentView()
}
