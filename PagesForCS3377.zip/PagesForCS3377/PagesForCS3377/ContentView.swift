//
//  ContentView.swift
//  TestingUI
//
//  Created by John Rydberg on 4/17/24.
//

import SwiftUI

struct ContentView: View {
    @State private var name:String = ""
    @State private var password:String = ""
    @State private var hidepass:String = "********"
    @State private var forgotEmail:String = ""
    @State private var createname:String = ""
    @State private var createpassword:String = ""
    @State private var settingPassword:String = ""
    @State private var settingPassword2:String = ""
    @State private var dontMatch = false
    @State private var lensChosen = 0
    @State private var results = "resultsresultsresultsresultsresultsresults"
    @State private var question = "Do creators have a moral obligation to regulate AI-generated content?"
    @State private var currentPresetQ = "Placeholder"

    //0:login,  1:forgot password,  2: reset password,  3: sign up
    //4:ask question page,  5: results page,  6: preset questions page
    //7: preset questions list page
    @State var screen = 8
    var body: some View {
        if screen == 0{
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:90 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 160, y: 90)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:45 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 245, y:0)
            
            
            Text("Sign in").font(.custom("Jomhuria-Regular", fixedSize:90 )).shadow(radius: 5, x:0, y :7).position(x:130,y:-50)
            
            
            VStack(alignment:.leading,spacing:30){
                TextField("Email or Username", text: $name).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().padding(0.0).foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
                
                TextField("Password", text: $password).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
            }.position(x:200,y:-40)
            
            
            Button(action:{
                //change to forgot password page
                screen = 1
            }){
                Text("Forgot Password ?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.black)
            }.position(x:260,y:-70)
            
            HStack{
                Button(action:{
                    screen = 4
                    
                }){
                    Text("Sign in").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 115)
                        .foregroundColor(.white)
                        .background(Color(red: 0.5, green: 0.15, blue: 0.72, opacity: 1.0))
                    .cornerRadius(30)          }
            }.position(x:200,y:-60)
            
            HStack{
                Text("Don't Have an account?").font(.custom("Jomhuria-Regular", fixedSize:35 ))
                
                
                Button(action:{
                    //change to sign up page
                    screen = 3
                }){
                    Text("Sign Up").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.black)
                }
                
            }
            
        }
        if screen == 1 {
            
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:90 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 160, y: 90)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:45 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 245, y:0)
            
            
            Text("Forgot Password?").font(.custom("Jomhuria-Regular", fixedSize:60 )).shadow(radius: 2, x:0, y :3).position(x:170,y:-50)
            
            Text("Enter your email to receive a link to reset your password").font(.custom("Jomhuria-Regular", fixedSize:36 )).shadow(radius: 2, x:0, y :3).frame(width: 300).position(x:185,y:-110)
            
            TextField("Email", text: $forgotEmail).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray).position(x:200,y:-70)
            
            
            
            HStack{
                Button(action:{
                    //Button to send reset email, currently just changes to reset password screen
                    screen = 2
                }){
                    Text("Send").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 115)
                        .foregroundColor(.white)
                        .background(Color(red: 0.5, green: 0.15, blue: 0.72, opacity: 1.0))
                    .cornerRadius(30)          }
            }.position(x:200,y:-110)
            
            HStack{
                Text("Already have an account?").font(.custom("Jomhuria-Regular", fixedSize:35 ))
                
                
                Button(action:{
                    //change to login page
                    screen = 0
                }){
                    Text("Sign In").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.black)
                }
                
            }
        }
        //reset password screen
        if screen == 2{
            
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:90 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 160, y: 90)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:45 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 245, y:-20)
            
            Text("Reset your Password").font(.custom("Jomhuria-Regular", fixedSize:60 )).shadow(radius: 2, x:0, y :3).position(x:200,y:-50)
            
            VStack(alignment:.leading,spacing:30){
                TextField("Enter New Password", text: $settingPassword).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().padding(0.0).foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
                
                TextField("Confirm Password", text: $settingPassword2).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
            }.position(x:200,y:-55)
            
            
            HStack{
                Button(action:{
                    //Button to sign in, current just sends you back to the starting page
                    if settingPassword == settingPassword2{
                        screen = 0
                        
                    }else{
                        dontMatch = true
                    }
                    
                    
                }){
                    Text("Confirm").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 115)
                        .foregroundColor(.white)
                        .background(Color(red: 0.5, green: 0.15, blue: 0.72, opacity: 1.0))
                    .cornerRadius(30)          }
                
                
            }.position(x:200,y:-10)
            
            if dontMatch == true{
                Text("passwords do not match").font(.custom("Jomhuria-Regular", fixedSize:40 )).position(x:200, y:-60).foregroundColor(.red)
            }
            
            
            
        }
        //sign up page
        if screen == 3{
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:90 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 160, y: 90)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:45 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 245, y:0)
            
            
            Text("Want to sign up?").font(.custom("Jomhuria-Regular", fixedSize:60 )).shadow(radius: 2, x:0, y :3).position(x:170,y:-50)
            
            Text("Enter your email and desired password to create an account").font(.custom("Jomhuria-Regular", fixedSize:36 )).shadow(radius: 2, x:0, y :3).frame(width: 300).position(x:185,y:-110)
            
            VStack(alignment:.leading,spacing:30){
                TextField("Enter Email", text: $createname).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().padding(0.0).foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
                
                TextField("Enter Password", text: $createpassword).padding(.vertical, 6.0).padding(.horizontal, 30.0).frame(width: 320.0, height: 55.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).cornerRadius(100)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray)
            }.position(x:200,y:-95)
            
            
            HStack{
                Button(action:{
                    //Button to sign in, current just sends you back to the starting page
                    screen = 0
                    
                }){
                    Text("Sign up").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 115)
                        .foregroundColor(.white)
                        .background(Color(red: 0.5, green: 0.15, blue: 0.72, opacity: 1.0))
                    .cornerRadius(30)          }
            }.position(x:200,y:-10)
            
            HStack{
                Text("Already have an account?").font(.custom("Jomhuria-Regular", fixedSize:35 ))
                
                
                Button(action:{
                    //change to login page
                    screen = 0
                }){
                    Text("Log In").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.black)
                }
                
            }
            
        }
        //ethical questions page
        if screen == 4{
            Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:52 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 180, y: 40)
            
            Text("HEROS").font(.custom("Lemon-Regular", fixedSize:28 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 225, y:-45)
            
            
            Text("Got an ethcial dilemma?").font(.custom("Lemon-Regular", fixedSize:24 )).shadow(radius: 2, x:0, y :3).position(x:170,y:-60).fixedSize(horizontal: true, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
            
            Text("ASK ME !").font(.custom("Lemon-Regular", fixedSize:24 )).shadow(radius: 2, x:0, y :3).frame(width: 300).position(x:90,y:-65)
            
            TextField("Type your question...", text: $question).padding(.bottom, 80.0).padding(.horizontal, 30.0).frame(width: 350.0, height: 140.0).fixedSize(horizontal: true, vertical: false).background(Rectangle().padding(0.0).foregroundColor(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 1.0)).shadow(radius: 3, x:0, y :3).cornerRadius(30)).font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(.gray).position(x:200,y:-60)
            
            Text("Select response perspective:").font(.custom("Lemon-Regular", fixedSize:20 )).shadow(radius: 2, x:0, y :3).frame(width: 370).position(x:200,y:-60)
            
            
            VStack(alignment: .leading, spacing: 20 ){
                Button(action:{
                    //positive response
                    lensChosen = 0
                    screen = 5
                    
                }){
                    Text("positive").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 52)
                        .foregroundColor(.white)
                        .background(Color(red: 0.1, green: 0.6, blue: 0.2, opacity: 1.0))
                    .cornerRadius(30)          }
                
                Button(action:{
                    //neutral response
                    lensChosen = 1
                    screen = 5
                
                    
                }){
                    Text("neutral").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 55)
                        .foregroundColor(.white)
                        .background(Color(red: 1, green: 0.55, blue: 0.15, opacity: 1.0))
                    .cornerRadius(30)          }

                Button(action:{
                    //negative response
                    lensChosen = 2
                    screen = 5
                    
                }){
                    Text("negative").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 45)
                        .foregroundColor(.white)
                        .background(Color(red: 0.8, green: 0.0, blue: 0.0, opacity: 1.0))
                    .cornerRadius(30)          }

                
            }.position(x:200,y:-10)
            
        
                Text("Cant think of a question?").font(.custom("Lemon-Regular", fixedSize:22 ))
                
                
                Button(action:{
                    //sends to Present Questions Page
                    screen = 6
                    
                }){
                    Text("Explore Ethical Questions").font(.custom("Lemon-Regular", fixedSize:20 )).padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .fixedSize(horizontal: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                        .background(Color(.black))
                    .cornerRadius(30)          }

            
        }
        //results page
        if screen == 5 {
            VStack{
                Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:52 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 180, y: 40).fixedSize(horizontal:false, vertical:true)
                
                Text("HEROS").font(.custom("Lemon-Regular", fixedSize:28 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 225).fixedSize(horizontal:false, vertical:true)
                
                
                Text("Question").font(.custom("Lemon-Regular", fixedSize:16 )).foregroundColor(.gray).position(x: 200, y:40).fixedSize(horizontal:false, vertical:true)
                
                Text("\"" + question + "\"").font(.custom("Times", fixedSize:22 )).frame(width: 340).fixedSize(horizontal: true, vertical: false).position(x: 200, y:65).bold().scaledToFit()
                
                Spacer()
                
                Text("Perspective").font(.custom("Lemon-Regular", fixedSize:16 )).foregroundColor(.gray).position(x: 200, y:45).fixedSize(horizontal:false, vertical:true)
                
                if lensChosen == 0 {
                    Button(action:{
                        //positive response
                        
                    }){
                        Text("positive").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 52)
                            .foregroundColor(.white)
                            .background(Color(red: 0.1, green: 0.6, blue: 0.2, opacity: 1.0))
                        .cornerRadius(30)          }.position(x: 200, y:60).fixedSize(horizontal:false, vertical:true)
                }
                
                if lensChosen == 1 {
                    Button(action:{
                        //neutral response
                        lensChosen = 1
                       
                        
                        
                    }){
                        Text("neutral").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 55)
                            .foregroundColor(.white)
                            .background(Color(red: 1, green: 0.55, blue: 0.15, opacity: 1.0))
                        .cornerRadius(30)          }.position(x: 200, y:60).fixedSize(horizontal:false, vertical:true)
                }
                if lensChosen == 2 {
                    Button(action:{
                        //negative response
                        lensChosen = 2
                       
                        
                    }){
                        Text("negative").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 45)
                            .foregroundColor(.white)
                            .background(Color(red: 0.8, green: 0.0, blue: 0.0, opacity: 1.0))
                        .cornerRadius(30)          }.position(x: 200, y:60).fixedSize(horizontal:false, vertical:true)
                }
                    
                    Spacer()
                    
                Text("Results: ").font(.custom("Lemon-Regular", fixedSize:16 )).foregroundColor(.gray).position(x:60).position(x: 200, y:50).fixedSize(horizontal:false, vertical:true)
                    
                Text(results).font(.custom("Times", fixedSize:20 )).multilineTextAlignment(.leading).fixedSize(horizontal: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/, vertical: false).position(x: 200, y:50).scaledToFit()
                Spacer()
                Spacer()
                Spacer()
                Text("Want to keep Learning?").font(.custom("Lemon-Regular", fixedSize:16 )).foregroundColor(.gray).position(x: 200, y:0).fixedSize(horizontal:false, vertical:true)
                    
                    
                    
                    
                    Button(action:{
                        //sends to question page
                        screen = 4
                        question = ""
                        
                    }){
                        Text("Ask Another Question").font(.custom("Lemon-Regular", fixedSize:20 )).padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .fixedSize(horizontal: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(Color(.black))
                        .cornerRadius(30)          }
                    
                
                
                
               Spacer()
            }
        }
        //preset question asking page
        if screen == 6 {
            ScrollView{
                Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:52 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 180, y: 40).fixedSize(horizontal:false, vertical:true)
                
                Text("HEROS").font(.custom("Lemon-Regular", fixedSize:28 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 225, y:0).fixedSize(horizontal:false, vertical:true)
                
                
                Text("Question Generated:").font(.custom("Lemon-Regular", fixedSize:16 )).fixedSize(horizontal: true, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/).foregroundColor(.gray)
                
                Text(question).font(.custom("Jomhuria-Regular", fixedSize:36 )).frame(width: 300).fixedSize(horizontal:false, vertical:true).scaledToFit()
                
                
                
                Text("Select response perspective:").font(.custom("Lemon-Regular", fixedSize:16 )).frame(width: 370).position(x:200,y:0).foregroundColor(.gray)
                
                
                VStack(alignment: .leading, spacing: 20 ){
                    Button(action:{
                        //positive response
                        lensChosen = 0
                        
                    }){
                        Text("positive").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 52)
                            .foregroundColor(.white)
                            .background(Color(red: 0.1, green: 0.6, blue: 0.2, opacity: 1.0))
                        .cornerRadius(30)          }
                    
                    Button(action:{
                        //neutral response
                        lensChosen = 1
                    
                        
                    }){
                        Text("neutral").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 55)
                            .foregroundColor(.white)
                            .background(Color(red: 1, green: 0.55, blue: 0.15, opacity: 1.0))
                        .cornerRadius(30)          }

                    Button(action:{
                        //negative response
                        lensChosen = 2
                        
                    }){
                        Text("negative").font(.custom("Jomhuria-Regular", fixedSize:50 )).padding(.horizontal, 45)
                            .foregroundColor(.white)
                            .background(Color(red: 0.8, green: 0.0, blue: 0.0, opacity: 1.0))
                        .cornerRadius(30)          }

                    
                }.position(x:200,y:100)
                
            
                    
                
                    Button(action:{
                        //sends to Present Questions Page
                        question = currentPresetQ
                        screen = 6
                        
                    }){
                        Text("Submit").font(.custom("Lemon-Regular", fixedSize:20 )).padding(.horizontal, 70)
                            .padding(.vertical, 12)
                            .fixedSize(horizontal: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(Color(.black))
                        .cornerRadius(30)          }.position(x:200, y:80)

                
                Text("\n\n\n\n\n\n\n\n")
                
                Text("You want another default question?").font(.custom("Lemon-Regular", fixedSize:18 )).fixedSize(horizontal:false, vertical:true).position(x:200, y:0).foregroundColor(Color(red: 0.3, green: 0.1, blue: 0.1))
                
                Text("")
                Button(action:{
                    //generate another default question
                    
                    
                }){
                    Text("Generate Question").font(.custom("Lemon-Regular", fixedSize:20 )).padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .fixedSize(horizontal: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                        .background(Color(red: 0.3, green: 0.1, blue: 0.1))
                    .cornerRadius(30)          }.position(x:200, y:0)
                
                
                Text("or").font(.custom("Lemon-Regular", fixedSize:18 )).fixedSize(horizontal:false, vertical:true).position(x:200, y:0).foregroundColor(Color(red: 0.3, green: 0.1, blue: 0.1))
                
                Text("")
                Text("")
                Button(action:{
                    //send to preset questions page
                    screen = 7
                    
                }){
                    Text("See Questions List").font(.custom("Lemon-Regular", fixedSize:20 )).padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .fixedSize(horizontal: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                        .background(Color(red: 0.3, green: 0.1, blue: 0.1))
                    .cornerRadius(30)          }.position(x:200, y:0)
                
                
                
                Text("You have your own question?").font(.custom("Lemon-Regular", fixedSize:18 )).fixedSize(horizontal:false, vertical:true).position(x:200, y:0).foregroundColor(Color(red: 0.3, green: 0.1, blue: 0.1))
                Text("")
                
                Button(action:{
                    //send to ethical question page
                    screen = 4
                    question = ""
                    
                }){
                    Text("Type your question").font(.custom("Lemon-Regular", fixedSize:20 )).padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .fixedSize(horizontal: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                        .background(Color(red: 0.3, green: 0.1, blue: 0.1))
                    .cornerRadius(30)          }.position(x:200, y:0)
                
                
            }
            
        }
        //preset question list page
        if screen == 7{
            ScrollView{
                Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:52 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 180, y: 40).fixedSize(horizontal:false, vertical:true)
                
                Text("HEROS").font(.custom("Lemon-Regular", fixedSize:28 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 225, y:0).fixedSize(horizontal:false, vertical:true)
                
                
                Text("Question Generated:").font(.custom("Lemon-Regular", fixedSize:16 )).fixedSize(horizontal: true, vertical: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/).foregroundColor(.gray)
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Is it ethical to use AI for hiring decisions?"
                }){
                    Text("Is it ethical to use AI for hiring decisions?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                
                
                }
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Should social media platforms censor content?"
                }){
                    Text("Should social media platforms censor content?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9)).multilineTextAlignment(.leading).frame(width: 370).fixedSize(horizontal: true, vertical: false)
                }
                
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Is the widespread collection of data by tech companies justified?"
                }){
                    Text("Is the widespread collection of data by tech companies justified?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Do creators have a moral obligation to regulate AI-generated content?"
                }){
                    Text("Do creators have a moral obligation to regulate AI-generated content?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Is it ethical to develop autonomous weapons?"
                }){
                    Text("Is it ethical to develop autonomous weapons?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Should there be a right to digital privacy?"
                }){
                    Text("Should there be a right to digital privacy?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Is it moral to use technology for surveillance in public spaces?"
                }){
                    Text("Is it moral to use technology for surveillance in public spaces?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Should AI have rights or personhood?"
                }){
                    Text("Should AI have rights or personhood?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Is it ethical to use technology to enhance human capabilities?"
                }){
                    Text("Is it ethical to use technology to enhance human capabilities?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Should we implement technology to monitor employee productivity?"
                }){
                    Text("Should we implement technology to monitor employee productivity?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Is the use of deepfake technology ever justifiable?"
                }){
                    Text("Is the use of deepfake technology ever justifiable?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Do consumers have a moral duty to consider the ethics of the tech products they buy?"
                }){
                    Text("Do consumers have a moral duty to consider the ethics of the tech products they buy?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Is it ethical for AI to make life or death decisions in healthcare?"
                }){
                    Text("Is it ethical for AI to make life or death decisions in healthcare?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Should there be ethical limitations on genetic engineering?"
                }){
                    Text("Should there be ethical limitations on genetic engineering?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
                Button(action:{
                    //change to sign up page
                    screen = 6
                    question = "Is it moral to create AI that mimics human emotions?"
                }){
                    Text("Is it moral to create AI that mimics human emotions?").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.9))
                }
                
     
            }
        }
        if screen == 8{
            ScrollView{
                Text("ETHICAL").font(.custom("Jomhuria-Regular", fixedSize:52 )).foregroundColor(Color("ETHICAL")).shadow(radius: 5, x:0, y :7).position(x: 180, y: 40).fixedSize(horizontal:false, vertical:true)
                               
               Text("HEROS").font(.custom("Lemon-Regular", fixedSize:28 )).bold().foregroundColor(Color("HEROS")).shadow(radius: 5, x:0, y :7).position(x: 225, y:0).fixedSize(horizontal:false, vertical:true)
               
               Text("Welcome to Ethical Heroes").font(.custom("Jomhuria-Regular", fixedSize:42 )).foregroundColor(.purple).offset(x:-40)
               
               
               Text("Founded in February 2023 by a visionary trio - Abderrahim Latreche, Fawwaz Ashraf, and John Rydberg - Ethical Heroes emerged from a shared concern for the growing ethical dilemmas in the realm of technology. United by a belief in the power of ethical guidelines to shape the future of technological innovation, we embarked on a journey to foster accountability, transparency, and integrity in the tech industry.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 350).fixedSize(horizontal: true, vertical: true)
               
               Text("Our Mission").font(.custom("Jomhuria-Regular", fixedSize:42 )).foregroundColor(.purple).offset(x:-112)
               
               
               Text("To illuminate and address the ethical quandaries of technology, empowering creators and users alike to foster a digital world that prioritizes human dignity, privacy, and the common good above all.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 350).fixedSize(horizontal: true, vertical: true)
               Text("")
               
               Text("Our Vision").font(.custom("Jomhuria-Regular", fixedSize:42 )).foregroundColor(.purple).offset(x:-120).fixedSize(horizontal: true, vertical: true)
               
               
               Text("A future where technology serves as a force for positive change, enhancing human lives without compromising ethical values. We envision a world where every technological advancement is evaluated not just by its innovation, but by its impact on humanity and the planet.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 350).fixedSize(horizontal: true, vertical: true)
               
                HStack{
                    Text(".\n\n\n.\n\n\n.\n\n\n\n.\n\n\n\n.").bold().padding(.bottom, 20.0).font(.custom("Jomhuria-Regular", fixedSize:35 ))
                    VStack{
                        Text("")
                        Text("Our Core Values").font(.custom("Jomhuria-Regular", fixedSize:42 )).foregroundColor(.purple).offset(x:-100)
                        
                        
                        Text("Integrity: Upholding the highest ethical standards in all our endeavors.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 320).fixedSize(horizontal: true, vertical: false)
                        
                        
                        Text("Transparency: Promoting open and honest dialogue about the ethical implications of technology.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 300).fixedSize(horizontal: true, vertical: false)
                        
                        
                        Text("Accountability: Holding ourselves and the tech industry responsible for the societal impacts of technological advancements.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 300).fixedSize(horizontal: true, vertical: false)
                        Text("Inclusivity: Ensuring diverse perspectives are considered in the ethical discourse surrounding technology.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 300).fixedSize(horizontal: true, vertical: false)
                        
                        Text("Sustainability: Advocating for technology that sustains our planet for future generations.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 320).fixedSize(horizontal: true, vertical: false)
                        
                    }
       
                    }
                    
                    
                    Text("")
                    
                    Text("What We Do").font(.custom("Jomhuria-Regular", fixedSize:42 )).foregroundColor(.purple).offset(x:-115)
                    
                    
                    Text("Ethical Heroes is at the forefront of identifying and tackling ethical issues in technology. Through research, advocacy, and education, we strive to bring ethical considerations to the center of technological innovation. Our work spans from organizing forums for debate and discussion to developing resources and guidelines that aid tech companies in making ethically informed decisions.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 350).fixedSize(horizontal: true, vertical: false)
                Text("")
                
                Text("Join Us").font(.custom("Jomhuria-Regular", fixedSize:42 )).foregroundColor(.purple).offset(x:-140)
                
                
                Text("Are you passionate about shaping the ethical landscape of technology? We're looking for individuals who are curious, driven, and committed to our cause. If you're interested in making a difference, we'd love to hear from you.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 350).fixedSize(horizontal: true, vertical: false)
                Text("")
                
                Text("Contact Us").font(.custom("Jomhuria-Regular", fixedSize:42 )).foregroundColor(.purple).offset(x:-125)
                
                
                Text("Reach out to discuss, collaborate, or learn more about our initiatives. Email us at [YourEmail@ethicalheroes.com] or visit our office in Dallas, TX. Your insights and contributions can help shape a more ethical digital future.").font(.custom("Jomhuria-Regular", fixedSize:35 )).foregroundColor(Color(.black)).multilineTextAlignment(.leading).frame(width: 350).fixedSize(horizontal: true, vertical: false)
                    
                    
                    
                    
                }
                

        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}



#Preview {
    ContentView()
}
