//
//  PagesForCS3377App.swift
//  PagesForCS3377
//
//  Created by John Rydberg on 4/18/24.
//

import SwiftUI

@main
struct PagesForCS3377App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
